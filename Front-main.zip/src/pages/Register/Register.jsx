import { LinkItem } from "UI-KIT/Link/LinkItem";
import { Button } from "UI-KIT/Button/Button";
import { Form } from "UI-KIT/Form/Form";
import Input from "UI-KIT/Input/Input";
import { useFormik } from "formik";
import * as yup from "yup";

import "./Register.scss";
import { NAME_REGULAR, PASSWORD_REGULAR } from "services/regulars";

function Register() {
  const formik = useFormik({
    initialValues: {
      userName: "",
      userSurname: "",
      email: "",
      password: "",
      repeatPassword: "",
    },
    validationSchema: yup.object({
      userName: yup
        .string()
        .min(2, "Длина поля от 2 до 30 символов")
        .max(30, "Длина поля от 2 до 30 символов")
        .matches(NAME_REGULAR, "Введите корректное имя")
        .required("Поле обязательно для заполнения"),
      userSurname: yup
        .string()
        .min(2, "Длина поля от 2 до 30 символов")
        .max(30, "Длина поля от 2 до 30 символов")
        .matches(NAME_REGULAR, "Введите корректную фамилию")
        .required("Поле обязательно для заполнения"),
      email: yup
        .string()
        .email("Введите корректный E-mail")
        .min(6, "Длина поля от 6 до 254 символов")
        .max(254, "Длина поля от 6 до 254 символов")
        .required("Поле обязательно для заполнения"),
      password: yup
        .string()
        .min(8, "Длина поля от 8 до 30 символов")
        .max(30, "Длина поля от 8 до 30 символов")
        .matches(PASSWORD_REGULAR, "Введите корректный пароль")
        .required("Поле обязательно для заполнения"),
      repeatPassword: yup
        .string()
        .min(8, "Длина поля от 8 до 30 символов")
        .max(30, "Длина поля от 8 до 30 символов")
        .matches(PASSWORD_REGULAR, "Введите корректный пароль")
        .oneOf([yup.ref("password"), null], "Пароли не совпадают")
        .required("Поле обязательно для заполнения"),
    }),
    onSubmit: (values) => console.log(JSON.stringify(values, null, 2)),
  });

  const transformBlur = (event) => {
    formik.setFieldValue(event.target.name, event.target.value.trim());
    formik.handleBlur(event);
  };

  return (
    <main className="register">
      <h1 className="register__title">Добро пожаловать в Octopus</h1>
      <p className="register__subtitle">Заполните все поля, чтобы зарегистрироваться </p>
      <Form extClassName="register__form" onSubmit={formik.handleSubmit}>
        <div className="register__userName">
          <Input
            label="Имя"
            extClassNameInput="login__input"
            type="text"
            name="userName"
            id="registerUserName"
            value={formik.values.userName}
            onChange={formik.handleChange}
            error={
              formik.errors.userName && formik.touched.userName ? formik.errors.userName : null
            }
            onBlur={transformBlur}
          />
          <Input
            label="Фамилия"
            extClassNameInput="login__input"
            type="text"
            name="userSurname"
            id="registerUserSurname"
            value={formik.values.userSurname}
            onChange={formik.handleChange}
            error={
              formik.errors.userSurname && formik.touched.userSurname
                ? formik.errors.userSurname
                : null
            }
            onBlur={transformBlur}
          />
        </div>
        <Input
          label="E-mail"
          extClassNameInput="login__input"
          type="email"
          name="email"
          id="authEmail"
          value={formik.values.email}
          onChange={formik.handleChange}
          error={formik.errors.email && formik.touched.email ? formik.errors.email : null}
          onBlur={transformBlur}
        />
        <div className="register__tooltip-input">
          <Input
            label="Пароль"
            extClassNameInput="register__input"
            type="password"
            name="password"
            id="registerPassword"
            value={formik.values.password}
            onChange={formik.handleChange}
            error={
              formik.errors.password && formik.touched.password ? formik.errors.password : null
            }
            onBlur={transformBlur}
          >
            <ul className="register__tooltip-container">
              <li className="register__tooltip-item">от 8 до 30 символов</li>
              <li className="register__tooltip-item">
                должен содержать цифры и буквы / спецсимволы без пробелов
              </li>
            </ul>
          </Input>
        </div>

        <Input
          label="Повторите пароль"
          extClassNameInput="login__input"
          type="password"
          name="repeatPassword"
          id="registerRepeatPassword"
          value={formik.values.repeatPassword}
          onChange={formik.handleChange}
          error={
            formik.errors.repeatPassword && formik.touched.repeatPassword
              ? formik.errors.repeatPassword
              : null
          }
          onBlur={transformBlur}
        />
        <Button
          title="Зарегистрироваться"
          fill
          size="standard"
          disabled={!(formik.isValid && formik.dirty)}
        />
      </Form>
      <p className="register__suggestion">
        У вас уже есть учетная запись?{" "}
        <LinkItem
          url="/signin"
          title="Войти"
          extClassName="login__link"
          weight="400"
          lineColor="#479fba"
        />
      </p>
    </main>
  );
}

export default Register;
